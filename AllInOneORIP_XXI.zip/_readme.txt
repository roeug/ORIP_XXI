_Readme.txt for ORIP_XXI (All in one ZIP version)

=========== SYSTEM REQUIREMENTs
MS Windows 32-bit
Mouse highly recommended.

=========== USAGE
See PDF and HLP files

=========== To install
Unzip all files to any directory you want

=========== To uninstall
Delete all files from the program directory
 (May be reboot will be needed before deleting if the font was registered).

============================================================================
 The programs were developed with Borland Delphi5 Professional S/N_200-004-7302
In addition to Borland Visual Component Library freeware components were used:

 RX Library by
    Fedor Kozhevnikov  (fkozh@iname.com)
    Igor Pavluk        (igorp@mail.com)
    Serge Korolev      (korolev@usa.net)
 RX Library Web Site:   http://www.rxlib.com

 BKStringGrid by Bjorn Kvisli

 Objects (v4.17) (pre-existing  ADColls) by Andrew Driazgov andrey@asp.tstu.ru
                                                      
DLLs were built with GNU Compiler Collection Windows port GCC-2.95.2 for Mingw (i386-mingw32) 

                                                      
FREEWARE INFORMATION
====================
This program and data files are freeware, hence the authors give permission
for making copies of this program, and using the data files contained within,
'Without Restriction'

LIABILITY
==========

No liability whatsoever for the program operation, use of the data,
accuracy of the data, loss of information, or anything else is accepted
by the authors of these programs

DATA SOURCES
==========
See PDF and HLP files 

The authors work at
======================
Radio isotopes production laboratory of
"State Scientific Center of Russia Research Institute of Atomic Reactors"
Division of Radionuclide Sources and Preparations
 Contact address.
       E-mail: roeug20@gmail.com
       Post:   Evgeny G Romanov,
               Koroleva street 7-45,
               Dimitrovgrad,
               Ulyanovsk region,
               433506 Russia

https://github.com/roeug/ORIP_XXI

